<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Review $review
 * @var \Cake\Collection\CollectionInterface|string[] $users
 * @var \Cake\Collection\CollectionInterface|string[] $companies
 */
?>
<!--Header-->
<div class="row text-body-secondary">
	<div class="col-10">
		<h1 class="my-0 page_title"><?php echo $title; ?></h1>
		<h6 class="sub_title text-body-secondary"><?php echo $system_name; ?></h6>
	</div>
	<div class="col-2 text-end">
		<div class="dropdown mx-3 mt-2">
			<button class="btn p-0 border-0" type="button" id="orederStatistics" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
			<i class="fa-solid fa-bars text-primary"></i>
			</button>
				<div class="dropdown-menu dropdown-menu-end" aria-labelledby="orederStatistics">
            <?= $this->Html->link(__('List Reviews'), ['action' => 'index'], ['class' => 'dropdown-item', 'escapeTitle' => false]) ?>
				</div>
		</div>
    </div>
</div>
<div class="line mb-4"></div>
<!--/Header-->

<div class="card rounded-0 mb-3 bg-body-tertiary border-0 shadow">
<div class="card-body text-body-secondary">

<div class="card-title mb-0 mt-3">Internship Reviews</div>
<div class="tricolor_line mb-3"></div>

            <?= $this->Form->create($review,['type' =>'file']) ?>
            <fieldset>
                
            <div class="row g-3">  <!-- Added g-3 for consistent gutter spacing -->
    <!-- First Row: Company and Status -->
    <div class="col-md-6">
        <?php echo $this->Form->control('company_name', [
            'type' => 'text',
            'class' => 'form-control',
            'label' => 'Company Name',
            'required' => true
        ]); ?>
    </div>
    <div class="col-md-6">
    <?php echo $this->Form->control('status', [
        'class' => 'form-select',
        'label' => 'Review Status',
        'options' => [
            'accepted' => 'Accepted',
            'rejected' => 'Rejected',
            'edited' => 'Edited',
            'flagged' => 'Flagged'
        ],
        'empty' => '-- Select Status --'
    ]); ?>
</div>

    <!-- Second Row: Pros (Full Width) -->
    <div class="col-12">
        <?php echo $this->Form->control('pros', [
            'class' => 'form-control',
            'rows' => 3, 
            'label' => 'Positive Aspects'
        ]); ?>
    </div>

    <!-- Third Row: Cons (Full Width) -->
    <div class="col-12">
        <?php echo $this->Form->control('cons', [
            'class' => 'form-control',
            'rows' => 3,
            'label' => 'Areas for Improvement'
        ]); ?>
    </div>

    <!-- Fourth Row: Rating and Proof -->
    <div class="col-md-6">  <!-- Reduced width for rating -->
        <?php echo $this->Form->control('rating', [
            'class' => 'form-control',
            'min' => 1,
            'max' => 5,
            'type' => 'number',
            'label' => 'Rating (1-5)'
        ]); ?>
    </div>
    <div class="col-md-6">  <!-- Wider space for proof upload -->
        <?php echo $this->Form->control('intern_proof', [
            'class' => 'form-control',
            'type' => 'file',  
            'label' => 'Proof of Internship (Optional)'
        ]); ?>
    </div>
</div>
            </fieldset>
				<div class="text-end">
				  <?= $this->Form->button('Reset', ['type' => 'reset', 'class' => 'btn btn-outline-warning']); ?>
				  <?= $this->Form->button(__('Submit'),['type' => 'submit', 'class' => 'btn btn-outline-primary']) ?>
                </div>
        <?= $this->Form->end() ?>
    </div>
</div>