<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Review Internship Company</title>
    <style>
        @page{
            margin: 0px !important;
            padding: 0px !important;
        }
        <style>

    .text-body-secondary {
        color: #6c757d;
    }
    
    .page_title {
        font-weight: 700;
        color: #212529;
        margin-bottom: 0.25rem;
    }
    
    .sub_title {
        font-size: 0.875rem;
    }
    
    .line {
        height: 1px;
        background-color: #dee2e6;
        width: 100%;
    }
    
    .card {
        border-radius: 0.5rem !important;
        transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
    }
    
    .card:hover {
        transform: translateY(-2px);
        box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.1) !important;
    }
    
    .card-title {
        font-weight: 600;
        color: #212529;
    }
    
    .table {
        margin-bottom: 0;
    }
    
    .table th {
        font-weight: 600;
        color: #495057;
        white-space: nowrap;
        width: 30%;
    }
    
    .table td {
        color: #6c757d;
    }
    
    .table-sm td, .table-sm th {
        padding: 0.5rem;
    }
    
    .table-hover tbody tr:hover {
        background-color: rgba(0, 0, 0, 0.02);
    }
    
    .btn-outline-primary {
        border-width: 1px;
        font-weight: 500;
    }
    
    .btn-outline-primary:hover {
        background-color: #0d6efd;
        color: white;
    }
    
    .tricolor-line {
        height: 3px;
        background: linear-gradient(to right, #ff0000, #00ff00, #0000ff);
        margin: 10px 0;
        border-radius: 3px;
        opacity: 0.8;
    }
    
    .dropdown-menu {
        border-radius: 0.5rem;
        box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.1);
        border: 1px solid rgba(0, 0, 0, 0.05);
    }
    
    .dropdown-item {
        padding: 0.5rem 1rem;
        font-size: 0.875rem;
    }
    
    .dropdown-divider {
        margin: 0.25rem 0;
    }
    
    @media (max-width: 768px) {
        .col-10, .col-2 {
            width: 100%;
            text-align: center !important;
        }
        
        .dropdown {
            display: inline-block;
            margin-top: 1rem;
        }
        
        .card {
            margin-bottom: 1.5rem;
        }
    }
    
    .auto-paragraph {
        margin-bottom: 0.5rem;
    }
    
    .status-badge {
        display: inline-block;
        padding: 0.25rem 0.5rem;
        border-radius: 0.25rem;
        font-size: 0.75rem;
        font-weight: 600;
        text-transform: uppercase;
    }
    
    .status-active {
        background-color: #d1e7dd;
        color: #0f5132;
    }
    
    .status-inactive {
        background-color: #f8d7da;
        color: #842029;
    }
</style>
    </style>
</head>
<body>
<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Company $company
 */
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?= h($company->company_name) ?> - Internship Review Report</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 1000px;
            margin: 0 auto;
            padding: 20px;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 2px solid #0066cc;
            padding-bottom: 20px;
        }
        .header h1 {
            color: #0066cc;
            margin-bottom: 5px;
        }
        .header .subtitle {
            color: #666;
            font-size: 16px;
        }
        .logo {
            max-height: 80px;
            margin-bottom: 15px;
        }
        .section {
            margin-bottom: 25px;
            page-break-inside: avoid;
        }
        .section-title {
            color: #0066cc;
            border-bottom: 1px solid #ddd;
            padding-bottom: 5px;
            margin-bottom: 15px;
        }
        .company-info {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        .company-info th, .company-info td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        .company-info th {
            width: 30%;
            font-weight: bold;
            color: #555;
        }
        .rating {
            color: #ff9800;
            font-weight: bold;
        }
        .pros-cons {
            display: flex;
            margin-bottom: 20px;
        }
        .pros, .cons {
            width: 48%;
            padding: 15px;
            border-radius: 5px;
        }
        .pros {
            background-color: #e8f5e9;
            margin-right: 4%;
        }
        .cons {
            background-color: #ffebee;
        }
        .footer {
            text-align: center;
            margin-top: 40px;
            color: #777;
            font-size: 12px;
            border-top: 1px solid #ddd;
            padding-top: 10px;
        }
        .page-break {
            page-break-before: always;
        }
    </style>
</head>
<body>
    <div class="header">
        <?= $this->Html->image('logo.png', ['class' => 'logo', 'fullBase' => true]) ?>
        <h1><?= h($company->company_name) ?> - Internship Review</h1>
        <div class="subtitle">Generated on <?= date('F j, Y') ?></div>
    </div>

    <div class="section">
        <h2 class="section-title">Company Information</h2>
        <table class="company-info">
            <tr>
                <th>Company Name</th>
                <td><?= h($company->company_name) ?></td>
            </tr>
            <tr>
                <th>Industry</th>
                <td><?= h($company->industry) ?></td>
            </tr>
            <tr>
                <th>Website</th>
                <td><?= h($company->website) ?></td>
            </tr>
            <tr>
                <th>Status</th>
                <td><?= h($company->status) ?></td>
            </tr>
            <tr>
                <th>Rating</th>
                <td><span class="rating"><?= $this->Number->format($company->rating) ?>/5</span></td>
            </tr>
            <tr>
                <th>Verification</th>
                <td><?= h($company->proof) ?></td>
            </tr>
        </table>
    </div>

    <div class="section">
        <h2 class="section-title">Review Summary</h2>
        <div class="pros-cons">
            <div class="pros">
                <h3>Pros</h3>
                <?= $this->Text->autoParagraph(h($company->coprosns)); ?>
            </div>
            <div class="cons">
                <h3>Cons</h3>
                <?= $this->Text->autoParagraph(h($company->cons)); ?>
            </div>
        </div>
    </div>

    <?php if (!empty($company->internships)): ?>
    <div class="section">
        <h2 class="section-title">Internship Opportunities</h2>
        <table class="company-info">
            <tr>
                <th>Position</th>
                <th>Duration</th>
                <th>Start Date</th>
                <th>Paid</th>
            </tr>
            <?php foreach ($company->internships as $internship): ?>
            <tr>
                <td><?= h($internship->position) ?></td>
                <td><?= h($internship->duration) ?> months</td>
                <td><?= h($internship->start_date->format('M Y')) ?></td>
                <td><?= $internship->paid ? 'Yes' : 'No' ?></td>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>
    <?php endif; ?>

    <div class="footer">
        <p>This report was generated automatically by the Internship Reviewing Hub</p>
        <p>© <?= date('Y') ?> NuQisYaMin. All rights reserved. 2025</p>
    </div>
</body>
</html>
</body>
</html>