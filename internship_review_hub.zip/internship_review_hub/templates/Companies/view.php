<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Company $company
 */
?>
<!--Header-->
<div class="row text-body-secondary">
    <div class="col-10">
        <h1 class="my-0 page_title"><?php echo $title; ?></h1>
        <h6 class="sub_title text-body-secondary"><?php echo $system_name; ?></h6>
    </div>
    <div class="col-2 text-end">
        <div class="dropdown mx-3 mt-2">
            <button class="btn p-0 border-0" type="button" id="orederStatistics" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fa-solid fa-bars text-primary"></i>
            </button>
                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="orederStatistics">
                            <li><?= $this->Html->link(__('Edit Company'), ['action' => 'edit', $company->company_id], ['class' => 'dropdown-item', 'escapeTitle' => false]) ?></li>
                <li><?= $this->Form->postLink(__('Delete Company'), ['action' => 'delete', $company->company_id], ['confirm' => __('Are you sure you want to delete # {0}?', $company->company_id), 'class' => 'dropdown-item', 'escapeTitle' => false]) ?></li>
                <li><hr class="dropdown-divider"></li>
                <li><?= $this->Html->link(__('List Companies'), ['action' => 'index'], ['class' => 'dropdown-item', 'escapeTitle' => false]) ?></li>
                <li><?= $this->Html->link(__('New Company'), ['action' => 'add'], ['class' => 'dropdown-item', 'escapeTitle' => false]) ?></li>
                            </div>
        </div>
    </div>
</div>
<div class="line mb-4"></div>
<!--/Header-->

<div class="row">
    <div class="col-md-9">
        <div class="card rounded-0 mb-3 bg-body-tertiary border-0 shadow">
            <div class="card-body text-body-secondary">
            <h3><?= h($company->company_name) ?></h3>
    <div class="table-responsive">
        <table class="table">
                <tr>
                    <th><?= __('Company Name') ?></th>
                    <td><?= h($company->company_name) ?></td>
                </tr>
                <tr>
                    <th><?= __('Industry') ?></th>
                    <td><?= h($company->industry) ?></td>
                </tr>
                <tr>
                    <th><?= __('Website') ?></th>
                    <td><?= h($company->website) ?></td>
                </tr>
                <tr>
                    <th><?= __('Status') ?></th>
                    <td><?= h($company->status) ?></td>
                </tr>
                <tr>
                    <th><?= __('Proof') ?></th>
                    <td><?= h($company->proof) ?></td>
                </tr>
                <tr>
                    <th><?= __('Company Id') ?></th>
                    <td><?= $this->Number->format($company->company_id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Rating') ?></th>
                    <td><?= $this->Number->format($company->rating) ?></td>
                </tr>
                <tr>
                    <th><?= __('Pros') ?></th>
                    <td><?= $this->Text->autoParagraph(h($company->coprosns)); ?></td>
                </tr>
                <tr>
                    <th><?= __('Cons') ?></th>
                    <td><?= $this->Text->autoParagraph(h($company->cons)); ?></td>
                </tr>
                <th><?= __('Created') ?></th>
                    <td><?= h($company->created) ?></td>
                </tr>
                <tr>
                    <th><?= __('Modified') ?></th>
                    <td><?= h($company->modified) ?></td>
                </tr>
            </div>
            </table>
            </div>

            </div>
        </div>
    </div>
    
    <div class="col-md-3">
      <div class="card bg-body-tertiary border-0 shadow">
        <div class="card-body">

            <div class="card-title mb-0 mt-3">Download review details</div>
            <div class="tricolor-line md-3"></div>

        <table class="table table-sm table-hover">
            <tr>
                <td>Review Date</td>
                <td><?php echo date('M D, Y (h:i A)', strtotime($company->created)); ?></td>
            </tr>
            <tr>
                <td>Last Modified</td>
                <td><?php echo date('M D, Y (h:i A)', strtotime($company->modified)); ?></td>
            </tr>
        </table>

            <?php echo $this->Html->link(('Download PDF'), ['action' => 'pdf', $company->company_id], ['class'=> 'btn btn-sm btn-outline-primary', 
            'escapeTitle'=> false]); ?>
        </div>
      </div>
    </div>
</div>

<style>
   <style>
    /* General Styles */
    .text-body-secondary {
        color: #6c757d;
    }
    
    .page_title {
        font-weight: 700;
        color: #212529;
        margin-bottom: 0.25rem;
    }
    
    .sub_title {
        font-size: 0.875rem;
    }
    
    .line {
        height: 1px;
        background-color: #dee2e6;
        width: 100%;
    }
    
    /* Card Styles */
    .card {
        border-radius: 0.5rem !important;
        transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
    }
    
    .card:hover {
        transform: translateY(-2px);
        box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.1) !important;
    }
    
    .card-title {
        font-weight: 600;
        color: #212529;
    }
    
    /* Table Styles */
    .table {
        margin-bottom: 0;
    }
    
    .table th {
        font-weight: 600;
        color: #495057;
        white-space: nowrap;
        width: 30%;
    }
    
    .table td {
        color: #6c757d;
    }
    
    .table-sm td, .table-sm th {
        padding: 0.5rem;
    }
    
    .table-hover tbody tr:hover {
        background-color: rgba(0, 0, 0, 0.02);
    }
    
    /* Button Styles */
    .btn-outline-primary {
        border-width: 1px;
        font-weight: 500;
    }
    
    .btn-outline-primary:hover {
        background-color: #0d6efd;
        color: white;
    }
    
    /* Tricolor Line */
    .tricolor-line {
        height: 3px;
        background: linear-gradient(to right, #ff0000, #00ff00, #0000ff);
        margin: 10px 0;
        border-radius: 3px;
        opacity: 0.8;
    }
    
    /* Dropdown Styles */
    .dropdown-menu {
        border-radius: 0.5rem;
        box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.1);
        border: 1px solid rgba(0, 0, 0, 0.05);
    }
    
    .dropdown-item {
        padding: 0.5rem 1rem;
        font-size: 0.875rem;
    }
    
    .dropdown-divider {
        margin: 0.25rem 0;
    }
    
    /* Responsive Adjustments */
    @media (max-width: 768px) {
        .col-10, .col-2 {
            width: 100%;
            text-align: center !important;
        }
        
        .dropdown {
            display: inline-block;
            margin-top: 1rem;
        }
        
        .card {
            margin-bottom: 1.5rem;
        }
    }
    
    /* Pros/Cons Paragraphs */
    .auto-paragraph {
        margin-bottom: 0.5rem;
    }
    
    /* Status Badges */
    .status-badge {
        display: inline-block;
        padding: 0.25rem 0.5rem;
        border-radius: 0.25rem;
        font-size: 0.75rem;
        font-weight: 600;
        text-transform: uppercase;
    }
    
    .status-active {
        background-color: #d1e7dd;
        color: #0f5132;
    }
    
    .status-inactive {
        background-color: #f8d7da;
        color: #842029;
    }
</style>
</style>