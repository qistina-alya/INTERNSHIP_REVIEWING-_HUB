<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Company $company
 */
?>
<!-- Clean Header -->
<div class="row mb-4">
    <div class="col-8">
        <h2 class="fw-semibold mb-1"><?= h($title) ?></h2>
        <p class="text-muted small mb-0"><?= h($system_name) ?></p>
    </div>
    <div class="col-4 text-end">
        <?= $this->Html->link(__('List Companies'), 
            ['action' => 'index'], 
            ['class' => 'btn btn-sm btn-outline-secondary']
        ) ?>
    </div>
</div>

<!-- Clean Form Card -->
<div class="card border-0 shadow-sm">
    <div class="card-body p-4">
        <?= $this->Form->create($company, ['class' => 'row g-3']) ?>
            
            <div class="col-md-6">
                <?= $this->Form->control('company_name', [
                    'class' => 'form-control',
                    'label' => 'Company Name',
                    'required' => true
                ]) ?>
            </div>
            
            <div class="col-md-6">
                <?= $this->Form->control('industry', [
                    'class' => 'form-control',
                    'label' => 'Industry'
                ]) ?>
            </div>
            
            <div class="col-md-6">
                <?= $this->Form->control('website', [
                    'class' => 'form-control',
                    'label' => 'Website',
                    'type' => 'url',
                    'placeholder' => 'Enter site'
                ]) ?>
            </div> 
            
            <div class="col-md-6">
                <?= $this->Form->control('status', [
                    'class' => 'form-select',
                    'label' => 'Status',
                    'options' => [
                        'Active' => 'Active',
                        'Unverified' => 'Inactive',
                        'Blaclisted' => 'Prospect',
                        'Inactive' => 'Inactive',
                    ]
                ]) ?>
            </div>
            
            <div class="col-12">
                <?= $this->Form->control('pros', [
                    'class' => 'form-control',
                    'label' => 'Pros',
                    'rows' => 3
                ]) ?>
            </div>
            
            <div class="col-12">
                <?= $this->Form->control('cons', [
                    'class' => 'form-control',
                    'label' => 'Cons',
                    'rows' => 3
                ]) ?>
            </div>
            
            <div class="col-md-6">
    <label class="form-label">Rating: <span id="ratingValue" class="fw-bold"><?= $company->rating ?? 3 ?></span>/5</label>
    <div class="d-flex align-items-center">
        <?= $this->Form->control('rating', [
            'type' => 'range',
            'class' => 'form-range mx-3',
            'min' => 1,
            'max' => 5,
            'step' => 1,
            'label' => false,
            'id' => 'ratingSlider',
            'value' => $company->rating ?? 3
        ]) ?>
        <span class="badge bg-primary" id="ratingBadge"><?= $company->rating ?? 3 ?>/5</span>
    </div>
   
</div>
            
            <div class="col-md-6">
                <?= $this->Form->control('proof', [
                    'type' => 'file',
                    'class' => 'form-control',
                    'label' => 'Supporting Documents'
                ]) ?>
            </div>
            
            <div class="col-12 mt-4 pt-3 border-top">
                <div class="d-flex justify-content-end gap-2">
                    <?= $this->Form->button('Reset', [
                        'type' => 'reset',
                        'class' => 'btn btn-outline-secondary'
                    ]) ?>
                    <?= $this->Form->button(__('Save Company'), [
                        'type' => 'submit',
                        'class' => 'btn btn-primary'
                    ]) ?>
                </div>
            </div>
            
        <?= $this->Form->end() ?>
    </div>
</div>

<style>
    .form-control:focus, .form-select:focus {
        border-color: #86b7fe;
        box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25);
    }
    
    .card {
        border-radius: 0.5rem;
    }
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const ratingSlider = document.getElementById('ratingSlider');
    const ratingValue = document.getElementById('ratingValue');
    const ratingBadge = document.getElementById('ratingBadge');
    
    // Update display when slider changes
    ratingSlider.addEventListener('input', function() {
        const value = this.value;
        ratingValue.textContent = value;
        ratingBadge.textContent = value + '/5';
        
        // Update badge color based on value
        if (value < 2) {
            ratingBadge.className = 'badge bg-danger';
        } else if (value < 4) {
            ratingBadge.className = 'badge bg-warning text-dark';
        } else {
            ratingBadge.className = 'badge bg-success';
        }
    });
    
    // Trigger initial update in case there's a default value
    ratingSlider.dispatchEvent(new Event('input'));
});
</script>