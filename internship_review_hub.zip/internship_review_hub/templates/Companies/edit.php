<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Company $company
 */
?>
<!-- Header with Glassmorphism Effect -->
<div class="row">
    <div class="col-12">
        <div class="glass-card p-4 mb-4 rounded-4">
            <div class="row align-items-center">
                <div class="col-10">
                    <h1 class="my-0 display-5 fw-bold text-white"><?= h($title) ?></h1>
                    <p class="mb-0 text-white-50"><?= h($system_name) ?></p>
                </div>
                <div class="col-2 text-end">
                    <div class="dropdown">
                        <button class="btn btn-light btn-sm rounded-pill px-3" type="button" id="actionMenu" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-ellipsis-h"></i> Actions
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end shadow">
                            <li><?= $this->Html->link(__('View Company'), ['action' => 'view', $company->company_id], ['class' => 'dropdown-item', 'escapeTitle' => false]) ?></li>
                            <li><?= $this->Form->postLink(
                                __('Delete Company'),
                                ['action' => 'delete', $company->company_id],
                                ['confirm' => __('Are you sure you want to delete {0}?', $company->company_name), 'class' => 'dropdown-item text-danger', 'escapeTitle' => false]
                            ) ?></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><?= $this->Html->link(__('List All Companies'), ['action' => 'index'], ['class' => 'dropdown-item', 'escapeTitle' => false]) ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Edit Form with Modern Styling -->
<div class="card border-0 shadow-lg rounded-4 overflow-hidden">
    <div class="card-header bg-primary text-white py-3">
        <h2 class="h5 mb-0"><i class="fas fa-building me-2"></i> Company Profile</h2>
    </div>
    
    <div class="card-body p-5">
        <?= $this->Form->create($company, [
            'class' => 'needs-validation',
            'novalidate' => true,
            'type' => 'file',
            'url' => ['action' => 'edit', $company->company_id]
        ]) ?>
        
        <div class="row g-4">
            <!-- Basic Info Section -->
            <div class="col-md-6">
                <h4 class="mb-4 text-primary"><i class="fas fa-info-circle me-2"></i>Basic Information</h4>
                
                <div class="form-floating mb-3">
                    <?= $this->Form->text('company_name', [
                        'class' => 'form-control',
                        'placeholder' => 'Company Name',
                        'required',
                        'id' => 'company-name'
                    ]) ?>
                    <label for="company-name">Company Name</label>
                    <div class="invalid-feedback">Please provide a company name</div>
                </div>
                
                <div class="form-floating mb-3">
                    <?= $this->Form->text('industry', [
                        'class' => 'form-control',
                        'placeholder' => 'Industry',
                        'id' => 'industry'
                    ]) ?>
                    <label for="industry">Industry</label>
                </div>
                
                <div class="form-floating mb-3">
                    <?= $this->Form->url('website', [
                        'class' => 'form-control',
                        'placeholder' => 'Website',
                        'id' => 'website'
                    ]) ?>
                    <label for="website">Website</label>
                </div>
            </div>
            
            <!-- Rating & Status Section -->
            <div class="col-md-6">
                <h4 class="mb-4 text-primary"><i class="fas fa-chart-line me-2"></i>Evaluation</h4>
                
                <div class="mb-3">
                    <label class="form-label">Status</label>
                    <?= $this->Form->select('status', [
                        'Active' => 'Active',
                        'Unverified' => 'Unverified',
                        'Blacklisted' => 'Blacklisted',
                        'Inactive' => 'Inactive'
                    ], [
                        'class' => 'form-select',
                        'id' => 'status'
                    ]) ?>
                </div>
                
                <div class="mb-3">
                    <label class="form-label">Rating (1-5)</label>
                    <?= $this->Form->input('rating', [
                        'type' => 'range',
                        'class' => 'form-range',
                        'min' => 1,
                        'max' => 5,
                        'step' => 1,
                        'id' => 'rating',
                        'oninput' => "document.getElementById('ratingValue').innerText = this.value"
                    ]) ?>
                    <div class="d-flex justify-content-between">
                        <small>1 (Poor)</small>
                        <span id="ratingValue" class="badge bg-primary"><?= $company->rating ?? 5 ?></span>
                        <small>5 (Excellent)</small>
                    </div>
                </div>
            </div>
            
            <!-- Pros & Cons Section -->
            <div class="col-12">
                <h4 class="mb-4 text-primary"><i class="fas fa-balance-scale me-2"></i>Pros & Cons</h4>
                
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label text-success"><i class="fas fa-plus-circle me-1"></i> Pros</label>
                        <?= $this->Form->textarea('pros', [
                            'class' => 'form-control',
                            'rows' => 3,
                            'placeholder' => 'List the advantages of working with this company...',
                            'id' => 'pros'
                        ]) ?>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label text-danger"><i class="fas fa-minus-circle me-1"></i> Cons</label>
                        <?= $this->Form->textarea('cons', [
                            'class' => 'form-control',
                            'rows' => 3,
                            'placeholder' => 'List any disadvantages or concerns...',
                            'id' => 'cons'
                        ]) ?>
                    </div>
                </div>
            </div>
            
            <!-- Proof Section - PDF Upload -->
            <div class="col-12">
                <div class="mb-3">
                    <label class="form-label"><i class="fas fa-file-pdf me-1"></i> Supporting Documents (PDF)</label>
                    
                    <!-- Current file display (if exists) -->
                    <?php if (!empty($company->proof)): ?>
                    <div class="alert alert-info d-flex align-items-center mb-3" id="current-proof-container">
                        <i class="fas fa-file-alt me-2 fs-4"></i>
                        <div>
                            <p class="mb-1">Current file: <?= h(basename($company->proof)) ?></p>
                            <a href="<?= $this->Url->build('/uploads/proofs/' . h($company->proof)) ?>" 
                               target="_blank" class="btn btn-sm btn-outline-primary me-2">
                               <i class="fas fa-eye me-1"></i> View
                            </a>
                            <button type="button" class="btn btn-sm btn-outline-danger" 
                                    onclick="document.getElementById('delete-proof').value = '1'; 
                                             document.getElementById('current-proof-container').classList.add('d-none');
                                             document.getElementById('file-upload-wrapper').classList.remove('d-none');">
                               <i class="fas fa-trash me-1"></i> Remove
                            </button>
                        </div>
                    </div>
                    <input type="hidden" name="delete_proof" id="delete-proof" value="0">
                    <?= $this->Form->hidden('current_proof', ['value' => $company->proof]) ?>
                    <?php endif; ?>
                    
                    <!-- File upload input -->
                    <div class="file-upload-wrapper <?= !empty($company->proof) ? 'd-none' : '' ?>" id="file-upload-wrapper">
                        <?= $this->Form->control('proof_upload', [
                            'type' => 'file',
                            'label' => false,
                            'class' => 'form-control',
                            'accept' => '.pdf',
                            'id' => 'proof-upload'
                        ]) ?>
                        <div class="file-upload-info mt-2">
                            <small class="text-muted">Maximum file size: 5MB. Only PDF files are accepted.</small>
                        </div>
                    </div>
                    
                    <!-- Preview area for newly selected file -->
                    <div id="file-preview" class="mt-3 d-none">
                        <div class="card border-primary">
                            <div class="card-body p-2 d-flex align-items-center">
                                <i class="fas fa-file-pdf text-danger me-3 fs-1"></i>
                                <div class="flex-grow-1">
                                    <h6 class="mb-1 file-name">filename.pdf</h6>
                                    <small class="text-muted file-size">0 KB</small>
                                </div>
                                <button type="button" class="btn btn-sm btn-outline-danger" 
                                        onclick="cancelUpload()">
                                   <i class="fas fa-times"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Form Actions -->
        <div class="d-flex justify-content-between mt-5 pt-4 border-top">
            <?= $this->Html->link(__('Cancel'), ['action' => 'view', $company->company_id], ['class' => 'btn btn-outline-secondary px-4']) ?>
            <div>
                <?= $this->Form->button('Reset', [
                    'type' => 'reset',
                    'class' => 'btn btn-outline-warning px-4 me-2'
                ]) ?>
                <?= $this->Form->button(__('Save Changes'), [
                    'type' => 'submit',
                    'class' => 'btn btn-primary px-4'
                ]) ?>
            </div>
        </div>
        
        <?= $this->Form->end() ?>
    </div>
</div>

<style>
    .glass-card {
        background: rgba(41, 98, 255, 0.85);
        backdrop-filter: blur(10px);
        -webkit-backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.18);
    }
    
    .form-floating label {
        color: #6c757d;
    }
    
    .card {
        transition: transform 0.3s ease;
    }
    
    .card:hover {
        transform: translateY(-5px);
    }
    
    /* Custom file upload styling */
    .file-upload-wrapper {
        position: relative;
    }
    
    .file-upload-wrapper input[type="file"] {
        opacity: 0;
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        width: 100%;
        cursor: pointer;
    }
    
    .file-upload-wrapper::before {
        content: 'Choose PDF file or drag it here';
        display: block;
        background: #f8f9fa;
        border: 2px dashed #dee2e6;
        border-radius: 6px;
        padding: 40px 20px;
        text-align: center;
        color: #6c757d;
        font-weight: 500;
        transition: all 0.3s ease;
    }
    
    .file-upload-wrapper:hover::before {
        border-color: #0d6efd;
        background-color: #e7f1ff;
    }
    
    .highlight {
        background-color: #e7f1ff !important;
        border-color: #0d6efd !important;
        box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25);
    }
    
    .upload-alert {
        position: fixed;
        bottom: 20px;
        right: 20px;
        z-index: 1000;
        max-width: 400px;
    }
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Elements
    const fileInput = document.getElementById('proof-upload');
    const filePreview = document.getElementById('file-preview');
    const fileNameElement = document.querySelector('.file-name');
    const fileSizeElement = document.querySelector('.file-size');
    const deleteProofInput = document.getElementById('delete-proof');
    const currentProofContainer = document.getElementById('current-proof-container');
    const uploadWrapper = document.getElementById('file-upload-wrapper');
    const form = document.querySelector('form');

    // Drag and drop functionality
    if (uploadWrapper) {
        // Prevent default drag behaviors
        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            uploadWrapper.addEventListener(eventName, preventDefaults, false);
        });

        // Highlight drop area when item is dragged over it
        ['dragenter', 'dragover'].forEach(eventName => {
            uploadWrapper.addEventListener(eventName, highlight, false);
        });
        
        ['dragleave', 'drop'].forEach(eventName => {
            uploadWrapper.addEventListener(eventName, unhighlight, false);
        });

        // Handle dropped files
        uploadWrapper.addEventListener('drop', handleDrop, false);
    }

    // Handle file selection via click
    if (fileInput) {
        fileInput.addEventListener('change', handleFiles);
    }

    // Form submission handler
    if (form) {
        form.addEventListener('submit', function(e) {
            // Additional validation can be added here
            if (fileInput && fileInput.files.length > 0) {
                const file = fileInput.files[0];
                if (!validateFile(file)) {
                    e.preventDefault();
                    return false;
                }
            }
            return true;
        });
    }

    // Functions
    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    function highlight() {
        uploadWrapper.classList.add('highlight');
    }

    function unhighlight() {
        uploadWrapper.classList.remove('highlight');
    }

    function handleDrop(e) {
        const dt = e.dataTransfer;
        const files = dt.files;
        fileInput.files = files;
        handleFiles({ target: { files: files } });
    }

    function handleFiles(e) {
        const files = e.target.files;
        if (files.length > 0) {
            const file = files[0];
            
            if (validateFile(file)) {
                showFilePreview(file);
                // If uploading new file, make sure delete flag is reset
                if (deleteProofInput) deleteProofInput.value = '0';
                if (currentProofContainer) currentProofContainer.classList.add('d-none');
            } else {
                fileInput.value = '';
            }
        }
    }

    function validateFile(file) {
        // Check file type
        if (file.type !== 'application/pdf') {
            showAlert('Error', 'Only PDF files are allowed.', 'danger');
            return false;
        }
        
        // Check file size (5MB limit)
        if (file.size > 5 * 1024 * 1024) {
            showAlert('Error', 'File size exceeds 5MB limit.', 'danger');
            return false;
        }
        
        return true;
    }

    function showFilePreview(file) {
        fileNameElement.textContent = file.name;
        fileSizeElement.textContent = formatFileSize(file.size);
        filePreview.classList.remove('d-none');
    }

    function formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
    }

    function cancelUpload() {
        fileInput.value = '';
        filePreview.classList.add('d-none');
        if (deleteProofInput) deleteProofInput.value = '0';
        if (currentProofContainer) currentProofContainer.classList.remove('d-none');
        if (uploadWrapper) uploadWrapper.classList.remove('d-none');
    }

    function showAlert(title, message, type) {
        // Remove any existing alerts first
        const existingAlert = document.querySelector('.upload-alert');
        if (existingAlert) existingAlert.remove();
        
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type} upload-alert alert-dismissible fade show`;
        alertDiv.setAttribute('role', 'alert');
        alertDiv.innerHTML = `
            <strong>${title}</strong> ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        `;
        
        document.body.appendChild(alertDiv);
        
        // Auto-dismiss after 5 seconds
        setTimeout(() => {
            const bsAlert = new bootstrap.Alert(alertDiv);
            bsAlert.close();
        }, 5000);
    }

    // Make cancelUpload available globally
    window.cancelUpload = cancelUpload;
});
</script>