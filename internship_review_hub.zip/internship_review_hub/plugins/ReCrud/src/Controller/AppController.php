<?php
declare(strict_types=1);

namespace ReCrud\Controller;

use App\Controller\AppController as BaseController;

class AppController extends BaseController
{
}
