<?php
declare(strict_types=1);

namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Review Entity
 *
 * @property int $review_id
 * @property int $user_id
 * @property int $company_id
 * @property string $status
 * @property string $pros
 * @property string $cons
 * @property int $rating
 * @property string $intern_proof
 * @property \Cake\I18n\DateTime $created
 * @property \Cake\I18n\DateTime $modified
 *
 * @property \App\Model\Entity\User $user
 * @property \App\Model\Entity\Company $company
 */
class Review extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array<string, bool>
     */
    protected array $_accessible = [
        'user_id' => true,
        'company_id' => true,
        'status' => true,
        'pros' => true,
        'cons' => true,
        'rating' => true,
        'intern_proof' => true,
        'created' => true,
        'modified' => true,
        'user' => true,
        'company' => true,
    ];
}
